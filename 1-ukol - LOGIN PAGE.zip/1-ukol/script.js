function login() {

    const users = [
      "pepazdepa@seznam.cz.heslo123",
      "leoverner2007@seznam.cz.heslo123",
      "katejmriz@seznam.cz.heslo123",
    ];
  
    let userEmail, userPassword;
  
    userEmail = document.getElementById("emailIn").value;
    userPassword = document.getElementById("passwordIn").value;
  
    let userLogin = userEmail + "." + userPassword;
  
    let errors = 0;
  
    for (let i = 0; i < users.length; i++) {
      if (userLogin === users[i]) {
        alert("Úspěšně přihlášen!\nEmail: " + userEmail + "\nHeslo: " + userPassword);
  

        let table = document.getElementById("table");
        let newRow = table.insertRow();
        let cell1 = newRow.insertCell();
        let cell2 = newRow.insertCell();
        let cell3 = newRow.insertCell();
  

        cell1.innerHTML = userEmail;
        cell2.innerHTML = userPassword;
        cell3.innerHTML = new Date().toLocaleString();
  
        return;
      } else {
        errors++;
      }
    }
  
    if (errors >= users.length) {
      alert("Špatně zadané heslo nebo email!");
    }
  
  }
  